# Analisa Proyek — maknafinace.id (Wofins 2.1 / Makna Finance)

> **Acuan utama proyek** — mulai 21 Juli 2026, dokumen ini jadi referensi kerja untuk konteks, arsitektur, domain, dan rencana fitur. Baca file ini dulu sebelum menambah/mengubah fitur di `maknafinace.id`.
>
> Tanggal analisa: 21 Juli 2026  
> Path lokal: `/Applications/MAMP/htdocs/maknafinace.id`  
> Catatan: nama folder lokal misspelled (`maknafinace`); production domain: `maknafinance.id`
cd /Applications/MAMP/htdocs/maknafinace.id

---

## Ringkasan

Aplikasi ini adalah **ERP internal Makna Kreatif / Makna Finance (Wofins 2.1)** untuk bisnis wedding/event:

- CRM & penjualan (prospect → simulasi → order)
- Keuangan proyek (pembayaran, expense, nota dinas, P&L)
- Akuntansi (COA, jurnal, aset tetap, piutang, rekonsiliasi bank)
- HR lite (karyawan, payroll, cuti)
- Dokumen & SOP
- Landing/marketing publik + track WOFINS (ProspectApp)

**Bukan** multi-tenant. Satu panel admin Filament di `/admin`.

---

## 1. Tech Stack

### Backend

| Package | Versi / constraint |
|---------|-------------------|
| PHP | `^8.2` (dokumen sebut 8.3/8.4 di Hostinger) |
| Laravel | `^13.0` → v13.11.2 |
| Filament | `^5.0` → v5.6.5 |
| Livewire | `^4.0` → v4.3.0 |
| Filament Shield | `^4.0` → 4.2.0 |
| Spatie Permission | 7.4.1 |
| Spatie Activity Log | `^5.0` |
| Maatwebsite Excel | `^3.1` |
| DomPDF | `^3.1` |
| Log Viewer | `^3.24` |
| Socialite | `^5.23` |
| Filament Clear Cache | `^3.0` |

### Frontend

- Vite `^6.2.4`
- Tailwind CSS `^4.1.17`
- Theme Filament: `resources/css/filament/admin/theme.css`

### Environment (lokal)

- MySQL host: `127.0.0.1`
- MySQL port: `8889` (MAMP, bukan 3306)
- Database demo: `maknafinance_demo`
- Timezone: `Asia/Jakarta`
- Session / cache / queue: **database**

---

## 2. Arsitektur

### Filament Panel

- Provider: `app/Providers/Filament/AdminPanelProvider.php`
- ID: `admin`, path: `/admin`, brand: **Makna Kreatif**
- Default page: `ProjectDashboard`
- Plugins: Filament Shield (nav “Role”, group SDM), Filament Clear Cache
- Logo/favicon dinamis dari model `Company`

### Multi-tenancy

- **Tidak ada.** `Company` dipakai sebagai branding/settings, bukan tenant scope.

### Clusters

- `PendapatanCluster` — grup Finance
- `PengeluaranCluster` — grup Finance

### Custom Pages

- `Dashboard`, `ProjectDashboard`, `HrDashboard`
- `LaporanKeuangan`, `NetCashFlowReport`, `HelpCenter`

### Middleware

- `filament.auth`, `check.expiration`, `project.access`, `no-store`, `super-admin`
- Global web: `CheckUserExpiration`
- Routing: web + console saja; **tidak ada `routes/api.php`**

---

## 3. Inventaris Kode

| Area | Jumlah / fakta |
|------|----------------|
| Models | 57 |
| Filament Resources | ~41 |
| Policies | ~44 |
| Migrations | ~140 |
| Services | 4 |
| Observers | 5 |
| Jobs | 1 |
| Controllers | ~29 |
| Console Commands | ~27–28 |
| Filament Widgets | ~18 |
| Filament Pages | 6 |
| Filament Clusters | 2 |
| API routes | 0 |
| Multi-tenancy | Tidak |
| Test suite | Tidak ada folder `tests/` |

---

## 4. Models (57)

### CRM / penjualan / wedding ops

- `User`, `Employee`, `Status`
- `Prospect`, `ProspectApp`, `Industry`
- `Category`, `Product`, `ProductVendor`, `ProductPenambahan`, `ProductPengurangan`
- `Vendor`, `VendorPriceHistory`
- `SimulasiProduk`
- `Order`, `OrderProduct`, `OrderPenambahan`, `OrderPengurangan`
- `DataPembayaran`, `PaymentMethod`, `DataPribadi`
- `AccountManagerTarget`

### Keuangan / akuntansi

- `Expense`, `ExpenseOps`
- `PendapatanLain`, `PengeluaranLain`
- `Piutang`, `PembayaranPiutang`
- `ChartOfAccount`, `JournalBatch`, `JournalEntry`
- `FixedAsset`, `AssetDepreciation`
- `BankStatement`, `BankTransaction`, `BankReconciliationItem`
- `UnifiedTransaction` (virtual — menyatukan sumber transaksi untuk rekonsiliasi)
- `NotaDinas`, `NotaDinasDetail`

### HR

- `Payroll`
- `LeaveType`, `LeaveRequest`, `LeaveBalance`, `LeaveBalanceHistory`

### Dokumen / konten / company

- `Document`, `DocumentCategory`, `DocumentApproval`, `DocumentRecipient`, `DocumentAttachment`
- `Documentation`, `DocumentationCategory`
- `Sop`, `SopCategory`, `SopRevision`
- `Blog`
- `Company`, `CompanyLogo`

### Relasi inti (ringkas)

- **Order** → user (AM), prospect, product, order products, pembayaran, expenses, penambahan/pengurangan, journal batches
- **Product** → category, vendor(s), parent/children, penambahan/pengurangan, orders
- **Prospect** → orders, user/employee, product
- **Document** → category, creator, approvals, recipients, attachments
- **JournalBatch** → journal entries, morph `referenceable`

---

## 5. Filament Resources (~41)

| Resource | Grup nav (tipikal) |
|----------|-------------------|
| AccountManagerTarget | Penjualan |
| ActivityLog | Sistem |
| BankStatement (+ reconciliation) | Keuangan |
| Blog | Konten |
| Category, Product, Prospect, Order, SimulasiProduk, Vendor | Penjualan |
| ChartOfAccount, JournalBatch, FixedAsset | Keuangan |
| Company, CompanyLogo | Administrasi |
| DataPembayaran | Finance |
| DataPribadi, Employee, User, Status, Payroll | SDM |
| Document, DocumentCategory | Administrasi |
| Documentation, DocumentationCategory | Knowledge Base |
| Expense, ExpenseOps, NotaDinas, NotaDinasDetail | Keuangan |
| Industry, ProspectApp | WOFINS |
| LeaveBalance, LeaveRequest, LeaveType | Manajemen Cuti |
| PaymentMethod, Piutang, PembayaranPiutang | Keuangan |
| PendapatanLain, PengeluaranLain | Finance (cluster) |
| Sop, SopCategory | Administrasi |

Shield juga menambah manajemen **Role** di grup SDM.

---

## 6. Database

- ~140 file migrasi di `database/migrations/`
- Tabel Spatie: `permissions`, `roles`, `model_has_*`, `role_has_permissions`

### Domain tabel utama

**Framework:** users, sessions, cache, jobs, failed_jobs, …

**Bisnis:** categories, statuses, employees, vendors, prospects, products, simulasi_produks, orders, order_products, payment_methods, data_pembayarans, data_pribadis, expenses, expense_ops, bank_statements, account_manager_targets, pendapatan_lains, pengeluaran_lains, industries, prospect_apps, …

**Admin/docs:** sop_*, nota_dinas*, company_logos, blogs, companies, documents*, documentations*, …

**HR:** payrolls, leave_*

**Akuntansi:** chart_of_accounts, fixed_assets, asset_depreciations, journal_*, piutangs, pembayaran_piutangs, bank_transactions, bank_reconciliations*, activity_log

---

## 7. Routes

### `routes/web.php`

| Area | Contoh |
|------|--------|
| Marketing publik | `/`, `/harga`, `/product`, `/kontak`, `/blog/*`, `/pendaftaran`, `/features/*` |
| Lead | `/prospect`, `/prospect-app` |
| Auth front | `/login`, `/register`, forgot/reset |
| Profile | `/profile/*`, admin-tools (super_admin) |
| PDF/report (auth) | invoice, payroll slip, journal, expense, cash flow, AM report, nota dinas, simulasi, SOP |
| Bank recon | `/admin/reconciliation/{download-pdf,auto-match,unmark}` |
| Docs | `/docs`, `/docs/{slug}` |
| Debug | `/_phpinfo` (super_admin) |

Filament: `/admin/*`

### `routes/console.php` (schedule)

- Yearly: `targets:generate --auto-12-months`
- Daily: `targets:generate --update`
- Monthly: `activitylog:clean`

---

## 8. Services / Jobs / Observers

### Services (`app/Services/`)

| Service | Peran |
|---------|--------|
| `OrderFinance` | Grand total order, pembayaran, expense, profit |
| `OrderJournalService` | Auto jurnal dari order/pembayaran/expense ke COA |
| `ReconciliationService` | Auto-match bank dengan skor confidence |
| `ProductPricingCalculator` | Normalisasi harga vendor/produk |

### Observers

- `UserObserver` — leave balance saat user dibuat
- `LeaveRequestObserver`
- `OrderObserver`, `BankStatementObserver` — last-edited tracking
- `DocumentObserver` — auto-numbering

### Jobs

- `LogoutExpiredUsers`

### Imports / Exports

- Import: BankStatement, BankReconciliation, ExpenseOps
- Export: Product, ExpenseOps, Reconciliation

---

## 9. Auth & Roles

- Auth: Laravel session + Filament login `/admin`
- Front auth: `Front\AuthController`
- Spatie Permission + Filament Shield (`super_admin` aktif)
- Policies ~44 file di `app/Policies/`
- Gate Log Viewer → `super_admin` only

### Role (seed)

- `super_admin`
- `Account Manager`
- `admin`
- `employee`
- `finance`
- `Event Manager`

Kode juga merujuk role `hr` dan variasi casing `Finance` vs `finance` — perlu hati-hati konsistensi nama role.

Kontrol tambahan:

- User `terminated` / `inactive` / `expire_date` kadaluarsa → tidak bisa akses panel
- Middleware `EnsureSuperAdmin` untuk phpinfo, admin-tools, dll.

Socialite (Google) terkonfigurasi di config, tapi route OAuth belum terlihat aktif di `routes/`.

---

## 10. Alur Bisnis Inti

```
Prospect → Product / Simulasi → Order (project)
                ↓
    DataPembayaran / Expense / Nota Dinas
                ↓
     Journal Entries + Bank Reconciliation
```

Widget yang merujuk **Akad / Resepsi** menegaskan domain wedding/event.

---

## 11. Folder & Dokumen Terkait

| Path | Keterangan |
|------|------------|
| `analisa/` | Folder analisa (file ini) |
| `docs/metode_penyusutan.md` | Metode penyusutan aset tetap |
| `.info.md` | Catatan deploy Hostinger, artisan, multi-domain |
| `.memory.md` | Memory proyek (upgrade Laravel 13, warning migrasi, dll.) |
| `app/Exports/`, `app/Imports/` | Excel I/O |
| `app/Filament/Clusters/` | Pendapatan / Pengeluaran |
| `database/seeders/` | ~50 seeder |

### Domain server (dari `.info.md`)

- maknafinance.id
- update.maknakreatif.id
- wofins.id
- thewhitefinance.com
- patrononline.id
- prasetyowo.com

---

## 12. Catatan / Risiko (dari `.memory.md`, per Mei 2026)

1. Pernah tercatat **migrasi pending** — cek ulang dengan `php artisan migrate:status`
2. Debug mode pernah ON di lokal — jangan deploy dengan debug production
3. Log file bisa sangat besar — perlu rotate/clear
4. Path logo production kadang muncul di error lokal (storage belum sync)
5. Tidak ada test suite
6. Commit message di git cenderung generik (`Update`)

### Perintah berguna (lokal)

```bash
php artisan optimize:clear
php artisan migrate:status
php artisan migrate
php artisan shield:generate --all
php artisan route:list
php artisan schedule:list
```

MySQL MAMP:

```bash
/Applications/MAMP/Library/bin/mysql80/bin/mysql -h 127.0.0.1 -P 8889 -u root -proot
```

---

## 13. Rencana ke depan

- **Aplikasi absen** — akan ditambahkan (belum ada di codebase saat analisa ini dibuat).
  - Rencana: modul absensi karyawan, kemungkinan terintegrasi dengan area HR yang sudah ada (`Employee`, `User`, cuti, payroll).
  - Status: **belum dikerjakan** (catatan rencana, 21 Juli 2026).
  - Catatan: absensi direncanakan ikut di **iOS native** (lihat analisa iOS).

- **iOS App Native** — keputusan: SwiftUI + Laravel API (Sanctum), scope ESS (profil/cuti/kompensasi); admin tetap web.
  - Dokumen khusus: [`ANALISA-IOS-APP.md`](./ANALISA-IOS-APP.md)
  - Status: analisa & keputusan selesai; implementasi belum dimulai (21 Juli 2026).

## 14. Analisa halaman / topik terkait

| Dokumen | Topik |
|---------|--------|
| [`ANALISA-PRODUCT-DOWNLOAD-PDF.md`](./ANALISA-PRODUCT-DOWNLOAD-PDF.md) | `/products/{slug}/download-pdf` — PDF paket wedding (DomPDF) |
| [`ANALISA-IOS-APP.md`](./ANALISA-IOS-APP.md) | iOS native ESS (SwiftUI + Sanctum API) |
---

## Kesimpulan Satu Kalimat

**Laravel 13 + Filament 5 ERP untuk bisnis wedding/event:** lead → quote → order/project → pembayaran/expense/nota dinas → jurnal & rekonsiliasi bank, plus HR/payroll/cuti dan manajemen dokumen/SOP, di belakang RBAC Shield pada panel `/admin` tunggal dengan situs marketing publik. Ke depan: modul absen + **iOS native ESS** (lihat `analisa/ANALISA-IOS-APP.md`).
