# Analisa iOS App Native — Wofins (`wofins.id`)

> Acuan induk: [`ANALISA-PROYEK.md`](./ANALISA-PROYEK.md)  
> Tanggal: 21 Juli 2026  
> Path lokal: `/Applications/MAMP/htdocs/wofins`  
> Domain target: **wofins.id**  
> Keputusan produk: **iOS native** (Swift / SwiftUI), bukan WebView/PWA sebagai target akhir.

---

## Verdict (ringkas)

| Pertanyaan | Jawaban |
|------------|---------|
| Bisa langsung pakai web `/profile` di iOS? | **Tidak** — auth session/CSRF, bukan token |
| Ada API siap konsumsi app? | **Tidak** — `routes/api.php` belum ada |
| Sanctum / token auth? | **Belum terpasang** |
| Layak jadi native app? | **Ya**, setelah API layer dibuat |
| Scope v1 yang masuk akal | **ESS karyawan** (profil, cuti, kompensasi) |

**Status kode saat analisa:** backend = ERP wedding/finance (Laravel 13 + Filament), UI karyawan di Blade `/profile`. **Implementasi API / iOS: belum dimulai.**

---

## 1. Keputusan

| Item | Keputusan |
|------|-----------|
| Platform | **iOS native** (SwiftUI) |
| Product / domain | **Wofins** → `wofins.id` |
| Target user v1 | Karyawan (Employee Self-Service / ESS) |
| Backend | Laravel di folder `wofins` + **API baru** |
| Auth mobile | **Laravel Sanctum** (Bearer token) |
| Admin / Filament | **Tetap web/desktop** — tidak masuk iOS v1 |
| Absensi | Roadmap setelah ESS stabil |

---

## 2. Kondisi codebase sekarang (fakta)

Dicek 21 Juli 2026 di `/Applications/MAMP/htdocs/wofins`:

| Area | Status |
|------|--------|
| `routes/api.php` | Tidak ada |
| `bootstrap/app.php` | Hanya register `web` (+ commands, health) |
| `laravel/sanctum` | Tidak ada di `composer.json` |
| `HasApiTokens` di `User` | Tidak ada |
| Controllers `Api/` | Tidak ada |
| Auth | Session cookie + CSRF (web + Filament) |
| Push (APNs/FCM) | Tidak ada |
| Modul absensi | Belum ada di kode (hanya rencana) |
| Git | Sudah dilepas dari repo maknafinance (standalone) |

Yang **sudah ada** dan bisa jadi sumber logic ESS:

- `/profile`, `/profile/compensation`, `/profile/schedule`, `/profile/edit`
- `/leave/*` (ajukan & status cuti)
- Slip gaji PDF (`PayrollSlipController`)
- Role/permission Spatie + Filament Shield

`config/cors.php` sudah menyebut path `api/*` / Sanctum CSRF — **persiapan saja**, belum terpakai.

---

## 3. Kenapa harus native + API (bukan wrap web)

Halaman acuan web: `http://127.0.0.1:8000/profile` (lokal)

| Kondisi sekarang | Dampak ke native |
|------------------|------------------|
| Auth = session cookie + CSRF | Tidak cocok URLSession / Swift |
| Tidak ada kontrak JSON | App tidak punya data layer |
| Profile = Blade server-render | UI web ≠ UI native |
| Admin Tools sangat padat | UX buruk di phone; biarkan desktop |

WebView/Capacitor hanya boleh jadi **prototipe sementara**, bukan arsitektur final.

---

## 4. Scope iOS v1 (ESS)

### Masuk (wajib)

1. Login / logout / ganti password  
2. Ringkasan profil (data pribadi + employment)  
3. Edit profil (+ upload avatar)  
4. Kompensasi & cuti (payroll ringkas, sisa cuti, statistik)  
5. Jadwal & riwayat cuti  
6. Ajukan cuti / lihat status cuti  

### Opsional v1.1

7. Slip gaji (PDF via signed URL)  
8. Push notification (status cuti disetujui/ditolak)  
9. **Absensi** (check-in/out — modul backend baru)

### Tidak masuk iOS (tetap web)

- Admin Tools (`/profile/admin-tools/*`)  
- Laporan keuangan / Filament `/admin`  
- Bank statement / rekonsiliasi  
- Nota dinas (kecuali nanti read-only light)  
- Role/permission management  
- Branding / company settings  
- CRM order/prospect (bukan fokus ESS v1)

---

## 5. Pemetaan web profile → layar iOS

| Web (sekarang) | Layar iOS | Sumber logic |
|----------------|-----------|--------------|
| `/profile` (show) | Home / Ringkasan | `ProfileController@overview` + sections |
| `/profile/compensation` | Kompensasi & Cuti | `hrSalaryLeaveViewData()` |
| `/profile/schedule` | Jadwal & Riwayat | leave requests upcoming/recent |
| `/profile/edit` + PATCH | Edit Profil | `ProfileController@update` |
| PUT password | Ganti Password | `updatePassword` |
| `/leave/*` | Form & list cuti | Leave controllers → di-API-kan |
| Sidebar Admin Tools | — | **Tidak di-port** |

File web terkait:

```
app/Http/Controllers/Profile/ProfileController.php
resources/views/profile/show.blade.php
resources/views/profile/compensation.blade.php
resources/views/profile/schedule.blade.php
resources/views/profile/edit.blade.php
resources/views/profile/partials/sidebar.blade.php
routes/web.php  (grup /profile)
```

---

## 6. Arsitektur target

```
┌─────────────────────┐         HTTPS + Bearer Token        ┌──────────────────────────┐
│  iOS App (SwiftUI)  │ ──────────────────────────────────► │  Laravel API (Sanctum)   │
│  - Auth             │                                     │  routes/api.php          │
│  - Profile          │ ◄────────────────────────────────── │  /api/v1/...             │
│  - Leave            │         JSON                        │  Policies / Roles        │
│  - (Absensi nanti)  │                                     │  DB Wofins / wofins.id   │
└─────────────────────┘                                     └──────────────────────────┘
                                                                      │
                                                                      ▼
                                                            Filament / Profile Web
                                                            (tetap untuk admin)
```

### Stack yang disarankan

| Layer | Pilihan |
|-------|---------|
| iOS UI | SwiftUI |
| Networking | URLSession (Alamofire opsional) |
| Auth storage | Keychain (token Sanctum) |
| Backend | Laravel 13 + Sanctum |
| API style | JSON REST `/api/v1` |
| Authz | Spatie roles/permissions (sama dengan web) |
| Base URL prod | `https://wofins.id` (atau subdomain API jika dipisah nanti) |

---

## 7. Rencana API v1 (kontrak awal)

Prefix: `/api/v1`  
Auth: `Authorization: Bearer {token}`  
Middleware: `auth:sanctum`

| Method | Endpoint | Keterangan |
|--------|----------|------------|
| POST | `/auth/login` | email + password → token |
| POST | `/auth/logout` | revoke token |
| GET | `/me` | user + roles + employment ringkas |
| PATCH | `/me` | update profil |
| POST | `/me/avatar` | upload avatar (multipart) |
| PUT | `/me/password` | ganti password |
| GET | `/me/compensation` | payroll latest + leave stats |
| GET | `/me/leave-requests` | list cuti (filter status/period) |
| POST | `/me/leave-requests` | ajukan cuti |
| GET | `/me/leave-balances` | sisa kuota cuti |
| GET | `/me/schedule` | upcoming + recent leaves |

### Jangan ikutkan dulu (dummy di web)

- `POST /profile/report`  
- `GET /profile/events`  
- `GET /profile/benefits`  

---

## 8. Pekerjaan backend (prasyarat native)

1. `composer require laravel/sanctum` + migrate  
2. Buat `routes/api.php` + versioning `v1` (daftarkan di `bootstrap/app.php`)  
3. `User` model: `HasApiTokens`  
4. API Controllers (pisah dari ProfileController web, atau extract service)  
5. Form Request + API Resources (JSON konsisten)  
6. Policies: user hanya akses data sendiri  
7. Rate limit login  
8. (Opsional) signed URL untuk PDF slip gaji  
9. Sesuaikan branding env untuk **wofins.id** (`APP_NAME`, `APP_URL`, mail, dll.) saat deploy domain ini  

**Estimasi kasar backend API ESS:** beberapa hari–1–2 minggu.  
**Estimasi iOS UI ESS v1:** 2–4 minggu setelah API stabil.

---

## 9. Pekerjaan iOS native

### Modul layar

1. Splash + Login  
2. Tab bar: Home | Cuti | Kompensasi | Akun  
3. Home: nama, role, next leave, quick actions  
4. Cuti: list, detail, form ajukan  
5. Kompensasi: ringkas gaji terakhir + kuota cuti  
6. Akun: edit profil, ganti password, logout  

### Non-fungsional

- Keychain untuk token  
- Handle 401 → force logout  
- Offline ringan (cache profil) — opsional v1.1  
- Minimum iOS: **16+** (atau 17+)

### App Store

- Privacy policy (avatar; lokasi jika absensi)  
- Akun demo untuk App Review  
- App Privacy labels sesuai data yang dikumpulkan  

---

## 10. Roadmap

| Fase | Isi | Status |
|------|-----|--------|
| **A** | Analisa & keputusan native (dokumen ini) | Done (wofins.id) |
| **B** | Sanctum + API `/api/v1` ESS | **Done** (fondasi + ESS profil/cuti/kompensasi — 21 Jul 2026) |
| **C** | SwiftUI app v1 (login, profil, cuti, kompensasi) | **Done** (scaffold di `ios/` — 21 Jul 2026) |
| **D** | Slip gaji PDF + push notifikasi | Pending |
| **E** | Modul **absensi** (API + native) | Pending |
| **F** | TestFlight → App Store | Pending |

Admin web & Filament **tidak diganti** oleh app.

---

## 10b. Urutan wajib (checklist)

Kerjakan **berurutan**. Jangan mulai SwiftUI penuh sebelum langkah backend login + `/me` jalan.

### Tahap 0 — Keputusan & lingkungan
1. Kunci scope v1 = ESS saja; admin tetap web.  
2. Apple Developer account (untuk TestFlight nanti).  
3. Mac + Xcode untuk build native.  
4. Backend lokal/staging **wofins** stabil (DB terpisah dari maknafinance bila production).

### Tahap 1 — Fondasi API (Laravel) — **wajib dulu**
5. Install & konfigurasi **Laravel Sanctum**.  
6. Migration `personal_access_tokens`.  
7. `HasApiTokens` di model `User`.  
8. `routes/api.php` + prefix `/api/v1`.  
9. `POST /api/v1/auth/login`  
10. `POST /api/v1/auth/logout`  
11. `GET /api/v1/me`  
12. Uji Postman: login → me → logout.

### Tahap 2 — API fitur ESS
13. Extract service bila perlu (`ProfileService`, `LeaveService`).  
14–21. Endpoint me/avatar/password/compensation/leave/schedule (lihat tabel §7).  
22. Policy self-only.  
23. Rate limit + Form Request.  
24. Dokumentasikan contoh JSON response.

### Tahap 3 — iOS native (SwiftUI) v1
25. Project Xcode (SwiftUI, iOS 16+).  
26. Auth + Keychain.  
27. API client + handle 401.  
28–31. Tab Home / Cuti / Kompensasi / Akun.  
32. Uji ke API staging/local (bukan production dulu).

### Tahap 4–6
33–35. Slip PDF, push, polish.  
36–39. Absensi (setelah ESS stabil).  
40–44. Privacy, TestFlight, App Store.

### Jangan dilakukan di awal
- Wrap `/profile` sebagai app final.  
- Port Admin Tools / Filament ke iOS v1.  
- Absensi sebelum login + cuti API jalan.

### Urutan tercepat ke app yang bisa dipakai
```
Sanctum → login/me API → SwiftUI login+home
      → cuti API → layar cuti
      → kompensasi API → layar kompensasi
      → edit profil/password
      → TestFlight
      → (nanti) absensi → App Store
```

---

## 11. Risiko & mitigasi

| Risiko | Mitigasi |
|--------|----------|
| Duplikasi logic ProfileController | Extract Service dipakai web + API |
| Permission tidak konsisten | Policy/Spatie yang sama |
| Token bocor | Keychain + HTTPS + revoke on logout/password change |
| Scope mengembang ke admin | Kunci PO: ESS only di v1 |
| Campur dengan maknafinance | Repo/git sudah dilepas; DB & deploy `wofins.id` terpisah |
| Dummy endpoint menyesatkan | Jangan expose ke API sampai data real |

---

## 12. Relasi dengan absensi

Absensi ideal di iOS:

- Check-in / check-out  
- Riwayat kehadiran  
- (Opsional) selfie + koordinat  

Ini **modul backend baru** — belum ada di codebase — dikonsumsi app native setelah ESS.

---

## 13. Catatan identitas produk

| Item | Saat analisa (lokal) | Target wofins.id |
|------|----------------------|------------------|
| Folder | `/Applications/MAMP/htdocs/wofins` | sama |
| `APP_NAME` di `.env` | masih "Makna Kreatif" | sesuaikan ke **Wofins** saat branding |
| Filament brand | Makna Kreatif | sesuaikan nanti |
| Git | tidak terhubung (standalone) | repo baru opsional, belum dipakai |
| Deploy Hostinger | path `.../domains/wofins.id/public_html` (lihat `.info.md`) | production app + API |

---

## 14. Ringkas eksekutif

- **Ya** — iOS native (SwiftUI) untuk **wofins.id**.  
- **Tidak** — jangan wrap `/profile` session web.  
- **Wajib** bangun Sanctum + `/api/v1` dulu.  
- Scope v1 = **ESS karyawan**; admin tetap web.  
- Absensi = fase berikutnya di app yang sama.

---

## Status dokumen

- Analisa & keputusan native untuk **wofins**: **selesai**  
- Fondasi API (Sanctum + login/logout/me): **selesai**  
- API ESS (profil, avatar, password, kompensasi, leave balances, schedule, leave-requests, leave-types): **selesai** (21 Jul 2026)  
- App iOS SwiftUI v1 (login + tab Home/Cuti/Kompensasi/Akun): **selesai** di `ios/` (build simulator OK, 21 Jul 2026)  
- TestFlight / polish / absensi: **belum**  
- Update dokumen ini setiap ada keputusan scope atau endpoint baru
