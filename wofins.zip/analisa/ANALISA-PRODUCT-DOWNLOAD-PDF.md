# Analisa Halaman — Product Download PDF

> Acuan: `analisa/ANALISA-PROYEK.md`  
> Tanggal: 21 Juli 2026  
> URL contoh: http://127.0.0.1:8000/products/wedding-nadila-by-request-luar-kota/download-pdf

---

## Ringkasan

Endpoint ini **mengunduh PDF rincian paket wedding** (komponen vendor, penambahan, pengurangan, kalkulasi harga + profit/loss). Bukan halaman HTML — response-nya file PDF via DomPDF.

Butuh **login** (`filament.auth`). Tanpa auth → redirect `302` ke `/`.

---

## Identitas Route

| Key | Value |
|-----|--------|
| URL | `/products/{product}/download-pdf` |
| Route name | `products.downloadPdf` |
| Binding | Model `Product` by **slug** (`getRouteKeyName()` → `slug`) |
| Controller | `App\Http\Controllers\ProductDisplayController@downloadPdf` |
| View PDF | `resources/views/products/pdf.blade.php` |
| Middleware | `filament.auth`, `no-store`, `throttle:60,1` |
| Authz | `Gate::authorize('view', $product)` → `ProductPolicy::view` |
| Library | `barryvdh/laravel-dompdf` (`Pdf` facade) |

Definisi di `routes/web.php` (~baris 228–230).

---

## Alur Request

```
GET /products/{slug}/download-pdf
        ↓
  filament.auth (+ no-store + throttle)
        ↓
  Route model binding Product (by slug)
        ↓
  Gate::authorize('view', $product)
        ↓
  Eager load: category, items.vendor, pengurangans,
              penambahanHarga.vendor, lastEditedBy
        ↓
  companyPreviewData() → company + logoSrc (base64)
        ↓
  Pdf::loadView('products.pdf', ...)
        ↓
  download('product-{slug}-{Ymd}.pdf')
```

Contoh nama file: `product-wedding-nadila-by-request-luar-kota-20260721.pdf`

---

## Produk Contoh (DB `mf_21jul`)

| Field | Value |
|-------|--------|
| ID | 1375 |
| Name | Wedding Nadila (By Request Luar Kota) |
| Slug | `wedding-nadila-by-request-luar-kota` |
| Category | Wedding Organizer |
| Pax | 1000 |
| `price` | 311.850.000 |
| `product_price` | 261.350.000 |
| `pengurangan` | 19.500.000 |
| `penambahan_publish` | 70.000.000 |
| `penambahan_vendor` | 69.000.000 |
| `is_active` | 1 |
| `is_approved` | 0 |
| Vendor items | 13 |
| Pengurangan rows | 4 |
| Penambahan rows | 6 |

---

## Isi PDF (`products/pdf.blade.php`)

1. **Header tetap** — nama app / alamat / telepon / email + logo  
2. **Info dokumen** — nama produk, kategori, pax, ref `PROD-{id}`, tanggal cetak, nama user  
3. **Package Components & Services** — daftar `product->items` (ProductVendor): deskripsi, harga vendor, harga public  
4. **Additional Price Details** — `penambahanHarga` (jika ada)  
5. **Reduction Details** — `pengurangans`  
6. **Price Calculation** — Harga Awal → Addition → Subtotal → Reduction → Total Paket → Profit/(Loss) (kolom Publish vs Vendor)  
7. **Tanda tangan** — Approval By (owner company) / Prepared By (lastEditedBy atau auth user)  
8. **Footer** — nama app + timestamp  

Font: Poppins dari `storage/fonts/`. Paper: A4 portrait, DPI 150.

---

## Entry Point UI

Tombol download muncul di preview detail produk:

- View: `resources/views/products/details-preview.blade.php`
- Komponen: `x-download-pdf-button` → `route('products.downloadPdf', $product)`
- Preview URL terkait: `/products/{slug}/details/preview`

---

## Endpoint / View Terkait (penting)

| Endpoint | View | Keterangan |
|----------|------|------------|
| `products.downloadPdf` | `products.pdf` | PDF khusus download (yang dianalisa) |
| `products.details` action=`download` | `products.details-preview` | **PDF lain** dari view preview HTML |
| `products.details` preview/print | `products.details-preview` | HTML di browser |
| `products.exportExcelDetail` | Excel export | Maatwebsite |

Ada **dua jalur PDF** berbeda untuk “download produk”. Isi/layout bisa tidak sama.

---

## Relasi Model yang Dipakai

- `Product::items()` → `ProductVendor` (+ `vendor`)
- `Product::penambahanHarga()` → `ProductPenambahan` (+ `vendor`)
- `Product::pengurangans()` → `ProductPengurangan`
- `Product::category()`, `lastEditedBy()`
- `Company::first()` untuk branding/signature

---

## Temuan / Isu

### 1. Auth wajib
Tanpa session login, request hanya dapat `302` ke home (bukan PDF).

### 2. Header branding — **FIXED 21 Jul 2026**
- View PDF memakai `$company` + `$logoSrc` dari controller.
- Nama, alamat (address/city/province/postal), phone, email dari model `Company` (fallback lama jika kosong).
- Controller juga mengirim `companyName`.

### 3. Bug HTML di loop items — **FIXED 21 Jul 2026**
Tag `</tr>` sudah ditambahkan di `@forelse($product->items)`.

### 4. Kalkulasi di view (bukan service) — **FIXED 21 Jul 2026**
PDF & preview memakai `ProductPricingCalculator::calculateForProduct()`.

### 5. Quantity
Total item memakai rumus service: `price_public` / `total_price` (atau `harga_* × quantity` jika kosong).

### 6. Duplikasi template PDF — **FIXED 21 Jul 2026**
`details/.../download` sekarang memanggil `downloadPdf()` → view `products.pdf` yang sama.

### 7. `is_approved = 0`
Produk contoh belum approved; tetap bisa di-download selama policy `view` mengizinkan.

---

## File Kunci

```
routes/web.php
app/Http/Controllers/ProductDisplayController.php
app/Services/ProductPricingCalculator.php
resources/views/products/pdf.blade.php
resources/views/products/details-preview.blade.php
```

---

## Perbaikan

| # | Item | Status |
|---|------|--------|
| 1 | Fix `</tr>` missing di loop items | **Done** |
| 2 | Branding dari `Company` + `logoSrc` controller | **Done** |
| 3 | Satu sumber rumus harga (service) | **Done** |
| 4 | Satukan 2 jalur PDF | **Done** |
| — | Fix `stripCurrency` (titik desimal `.00` jadi ×100) | **Done** |

---

## Status

- Analisa kode: **selesai**
- Perbaikan prioritas #1–#4: **selesai**
- Optimasi kecepatan PDF (21 Jul 2026):
  - Root cause: `@font-face` Poppins (TTF) di Blade → DomPDF ~**120s+**
  - Fix: DejaVu Sans bawaan DomPDF + logo di-compress untuk PDF
  - Hasil benchmark: ~**0.45s** (sebelumnya ~125s)

